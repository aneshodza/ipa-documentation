# frozen_string_literal: true

module WebhooksHelper
end
