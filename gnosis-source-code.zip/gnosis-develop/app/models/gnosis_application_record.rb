# frozen_string_literal: true

# rubocop:disable Rails/ApplicationRecord
class GnosisApplicationRecord < ActiveRecord::Base
  # rubocop:enable Rails/ApplicationRecord
  self.abstract_class = true
end
